"""Versioning controlled via Git Tag, check setup.py"""

__version__ = "4.5.0"
